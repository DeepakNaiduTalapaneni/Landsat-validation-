import smtplib
import streamlit as st
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os
import time as t
st.sidebar.image("pictures/RIT_hor_w.png", use_column_width=True)


def send_email(name, suggestion, user_email, company):
    """Send an email to the admin of the website with user feedback.

    Args:
        name (str): Name of the user
        suggestion (str): Suggestion provided by the user
        user_email (str): Email of the user
        company (str): Company of the user

    Returns:
        str: Message indicating the success or failure of email sending
    """
    login = "rit.landsat.validation.website@gmail.com"  # Replace with your email address
    to_email = "rit.landsat.validation.website@gmail.com"
    subject = "New Suggestion from Streamlit App"
    body = f"Name: {name}\nCompany: {company}\nSuggestion: {suggestion}\nUser Email: {user_email}"

    # Construct the message
    message = MIMEMultipart()
    message['From'] = login
    message['To'] = to_email
    message['Subject'] = subject

    message.attach(MIMEText(body, 'plain'))

    try:
        # Create SMTP session
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()  # Start TLS for security

        # Use environment variables for email and password
        server.login(login, "fnim skax ogsk iezx")  # Make sure EMAIL_PASSWORD is set in your environment variables

        server.send_message(message)  # Send email
        server.quit()  # Terminate the session
        return "Email sent successfully"
    except Exception as e:
        return f"Failed to send email: {str(e)}"

# Custom CSS for styling
st.markdown(
    """
    <style>
    .contact-info {
        background-color: #2E2E2E;
        color: white;
        padding: 20px;
        border-radius: 10px;
        margin-bottom: 20px;
    }
    .contact-info a {
        color: #FFD700;
        text-decoration: none;
    }
    .contact-info a:hover {
        text-decoration: underline;
    }
    .contact-form h2 {
        color: black;
    }
    </style>
    """,
    unsafe_allow_html=True
)

# Contact Information
st.markdown("<div class='contact-info'><h2 style='color: white;'>Contact Information</h2>"
            "<a href='mailto:adgpci@cis.rit.edu' style='color: #ADD8E6;'>Aaron Gerace</a>"+ " and " +  "<a href='mailto:eoncis@rit.edu' style='color: #ADD8E6;'>Rehman Eon</a></p></div>", unsafe_allow_html=True)

with st.container():
    with st.form(key='suggestion_form'):
        st.header("Leave your Comments here")
        st.write("If you have any suggestions or feedback, please fill out the form below and we'll get back to you as soon as possible.")
        name = st.text_input("Name", placeholder="Enter your name")
        user_email = st.text_input("Email Address", placeholder="Enter your email")
        company = st.text_input("Company", placeholder="Enter your company")
        suggestion = st.text_area("Comment", placeholder="Comment")
        submit_button = st.form_submit_button(label='Submit')

    # Handling form submission
    if submit_button:
        if suggestion and user_email and name:
            result = send_email(name, suggestion, user_email, company)
            st.success(result)
        else:
            st.error("Please enter both your email address and a suggestion before submitting.")

