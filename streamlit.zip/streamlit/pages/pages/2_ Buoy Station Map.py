import streamlit as st
import pandas as pd
import folium
from streamlit_folium import folium_static


csv_file_path = 'buoy/buoy_list.csv'
df = pd.read_csv(csv_file_path)
st.sidebar.image("pictures/RIT_hor_w.png", use_column_width=True)


# Ensure the 'Link' column exists in the DataFrame
if 'Link' not in df.columns:
    st.error("The CSV file must contain a 'Link' column.")
else:
    # Create a map centered on the United States
    center_coordinates = [37.0902, -95.7129]
    m = folium.Map(location=center_coordinates, zoom_start=4)

    # Add points to the map
    for _, row in df.iterrows():
        # Ensure the Site-Buoy ID is a string
        site_buoy_id = str(row['Site-Buoy ID'])
        
        # Create an HTML string for the popup with a link that opens in a new tab
        popup_content = f"""
        <div style="font-family: Arial, sans-serif; border-radius: 5px; padding: 10px; max-width: 200px;">
            <h4 style="margin: 0; color: #2C3E50;">Site-Buoy ID: {site_buoy_id}</h4>
            <hr style="margin: 5px 0;">
            <p style="margin: 0; color: #34495E;"><strong>Latitude:</strong> {row['Lat.']}</p>
            <p style="margin: 0; color: #34495E;"><strong>Longitude:</strong> {row['Lon.']}</p>
            <a href="{row['Link']}" target="_blank" style="display: block; margin-top: 10px; padding: 5px; background: #2980B9; color: white; text-align: center; text-decoration: none; border-radius: 3px;">Link</a>
        </div>
        """
        folium.Marker(
            location=[row['Lat.'], row['Lon.']],
            popup=folium.Popup(popup_content, max_width=300),
            tooltip=site_buoy_id
        ).add_to(m)

    # Add custom CSS to center the map
    st.markdown(
        """
        <style>
        .centered-map {
            display: flex;
            justify-content: center;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Display the map with centered container
    st.header("Buoy Observations")
    st.markdown('<div class="centered-map">', unsafe_allow_html=True)
    folium_static(m, width=850, height=700)  # Adjusted width and height
    st.markdown('</div>', unsafe_allow_html=True)

    st.subheader("Instructions to use the map:")
    st.write("1. Scroll up/down on the map to zoom in/out of the map.")
    st.write("2. Hover on the point to look up the buoy ID and click on the point to get more info on the buoy.")
    st.write("3. To get additional info on the buoy from the national data buoy center, click on the link.")

