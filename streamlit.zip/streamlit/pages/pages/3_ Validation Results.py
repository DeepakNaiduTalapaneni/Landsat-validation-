import streamlit as st
import pandas as pd
from datetime import datetime, timedelta
import plotly.express as px
from streamlit_plotly_events import plotly_events
import os, sys


if 'userdata' not in st.session_state:
    st.session_state.userdata = None


st.set_page_config(layout="wide")
st.sidebar.image("pictures/RIT_hor_w.png", use_column_width=True)


custom_css = """
<style>
.custom-button {
 display: inline-block;
 width: 100%;
 height: 50px;
 border-radius: 10px;
 border: 0.5px solid #ffffff;
 position: relative;
 overflow: hidden;
 transition: all 0.5s ease-in;
 z-index: 1;
 background-color: #444 !important; /* Gray color */
 color: white !important;
 cursor: pointer;
 text-align: center;
 vertical-align: middle;
 line-height: 50px;
}

div.stButton > button {
 display: inline-block;
 width: 100%;
 height: 50px;
 border-radius: 10px;
 border: 0.5px solid #ffffff;
 position: relative;
 overflow: hidden;
 transition: all 0.5s ease-in;
 z-index: 1;
 background-color: #444 !important; /* Gray color */
 color: white !important;
 cursor: pointer;
 text-align: center;
 vertical-align: middle;
 line-height: 50px;
 padding: 0;
}

div.stButton > button::before,
div.stButton > button::after {
 content: '';
 position: absolute;
 top: 0;
 width: 0;
 height: 100%;
 transform: skew(15deg);
 transition: all 0.5s;
 overflow: hidden;
 z-index: -1;
}

div.stButton > button::before {
 left: -10px;
 background: #000000;
}

div.stButton > button::after {
 right: -10px;
 background: #000000;
}

div.stButton > button:hover::before,
div.stButton > button:hover::after {
 width: 58%;
 background: #FFFFFF;
}

div.stButton > button:hover {
 color: #000000 !important; /* Black text on hover */
 transition: 0.3s;
}


</style>
"""

apply_filters_css = """
<style>
    button {
  /* Variables */
  --button_radius: 0.75em;
  --button_color: RED;
  --button_outline_color: #FFFFFF;
  font-size: 17px;
  font-weight: bold;
  border: none;
  border-radius: var(--button_radius);
  background: var(--button_outline_color);
  color: black; /* Set text color to black */
}

.button_top {
  display: block;
  box-sizing: border-box;
  border: 2px solid var(--button_outline_color);
  border-radius: var(--button_radius);
  padding: 0.75em 1.5em;
  background: var(--button_color);
  color: black; /* Ensure text color is black */
  transform: translateY(-0.2em);
  transition: transform 0.1s ease;
}

button:hover .button_top {
  /* Pull the button upwards when hovered */
  transform: translateY(-0.33em);
}

button:active .button_top {
  /* Push the button downwards when pressed */
  transform: translateY(0);
}

    </style>
"""

st.session_state.matching_row = None
data = None

def read_and_combine_csvs(folder_path, start_year, end_year):
    """Reads all CSV files in the folder and combines them into a single DataFrame.

    Args:
        folder_path (str): Path to the folder containing the CSV files.
        start_year (int): Start year for the CSV files.
        end_year (int): End year for the CSV files.

    Returns:
        pd.DataFrame: Combined DataFrame of all CSV files.
    """
    all_files = []
    missing_files = []
    
    for year in range(start_year, end_year + 1):
        file_path = os.path.join(folder_path, f"{year}.csv")
        if os.path.exists(file_path):
            df = pd.read_csv(file_path)
            all_files.append(df)
        else:
            missing_files.append(file_path)
    
    if all_files:
        combined_df = pd.concat(all_files, ignore_index=True)
        if missing_files:
            print(f"Missing files: {', '.join(missing_files)}")
        return combined_df
    else:
        return None
    
def toggle_with_input(label, key_toggle, key_input, default_toggle=False, default_input="0.0", input_type=float):
    container = st.container()
    with container:
        toggle = st.checkbox(label, key=key_toggle, value=default_toggle)
        if toggle:
            if label == "Buoy ID":
                # buoy_ids_list =  # Replace with your actual Buoy ID list
                selected_buoy_ids = st.multiselect('Select Buoy IDs', buoy_ids_list, default=None)
                return selected_buoy_ids
            
            if label == "Cloud cover % ":
                value = st.text_input(f"{label} less than", key=key_input, value=default_input)
                return float(value)
            else:
                value = st.text_input(f"{label} greater than", key=key_input, value=default_input)
                return float(value)

            return value

# Function to generate date ranges
def generate_date_range(start_year, end_year):
    years = [str(year) for year in range(start_year, end_year + 1)]
    months = [str(month) for month in range(1, 13)]
    return years, months

# Function to get the number of days in a month
def days_in_month(year, month):
    next_month = datetime(year, month % 12 + 1, 1) if month != 12 else datetime(year + 1, 1, 1)
    last_day = next_month - timedelta(days=1)
    return [str(day) for day in range(1, last_day.day + 1)]

buoy_ids_df = pd.read_csv('buoy/buoy-id.csv', converters={'Site-Buoy ID': str})
buoy_ids_list = buoy_ids_df['Site-Buoy ID'].tolist()
source=None

def filter_data(data, start_date, end_date, dp_value, distance_to_clouds_value, cloud_cover_value,buoy_id_value):
    filtered_data = data.copy()
    
    # Filter by date range
    filtered_data['Date'] = pd.to_datetime(filtered_data['Date']).dt.date
    filtered_data = filtered_data[(filtered_data['Date'] >= start_date) & (filtered_data['Date'] <= end_date)]
    
    # Filter by dewpoint depression
    if dp_value:
        filtered_data = filtered_data[filtered_data['DD (K)'] >= dp_value]
    
    # Filter by distance to clouds
    if distance_to_clouds_value:
        filtered_data = filtered_data[filtered_data['Distance to Cloud (Km)'] >= distance_to_clouds_value]
    
    # Filter by cloud cover
    if cloud_cover_value:
        filtered_data = filtered_data[filtered_data['Scene Cloud Cover (%)'] <= cloud_cover_value]

    # Filter by buoy ID
    if buoy_id_value:
        filtered_data['Buoy ID'] = filtered_data['Buoy ID'].astype(str)
        filtered_data = filtered_data[filtered_data['Buoy ID'].isin(buoy_id_value)]
    return filtered_data.reset_index(drop=True)

def plot1(userdata):
    fig = px.scatter(userdata,
                     y="B10 Radiance (W/m2/sr/um)",
                     x="B10 Model Radiance (W/m2/sr/um)",
                     hover_data=["Buoy ID", "Product ID", "Date"])

    fig.update_traces(marker=dict(size=5, color='red'), textposition='top center')

    hover_template = '<br>'.join([
        'B10 Radiance (W/m2/sr/um) = %{y}',
        'B10 Model Radiance (W/m2/sr/um) = %{x}',
        'Buoy ID = %{customdata[0]}',
        'Product ID = %{customdata[1]}',
        'Date = %{customdata[2]}'
    ])
    fig.update_traces(hovertemplate=hover_template)

    fig.update_layout(title='Band 10: Landsat Image Radiance vs. Buoy-Derived Modeled Radiance',
                      yaxis_title='B10 Landsat Image Radiance(W/m²/sr/μm)',
                      xaxis_title='B10 Buoy-Derived Model Radiance (W/m²/sr/μm)',
                      hoverlabel=dict(bgcolor="black", font_size=12, font_color="white"),
                      shapes=[
                          # Rectangle around the plot area
                          dict(type="rect",
                               xref="paper", yref="paper",
                               x0=0, y0=0, x1=1, y1=1,
                               line=dict(color="black", width=0.5)),
                      ],
                      plot_bgcolor='white',  # Background color inside the plot
                      paper_bgcolor='white',  # Background color outside the plot
                      font=dict(color='black'))

    # Set the same scale for both axes
    min_range, max_range = 5, 11

    fig.update_xaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=1)
    fig.update_yaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=1)

    # Add a diagonal line y=x
    fig.add_shape(type="line",
                  x0=min_range, y0=min_range, x1=max_range, y1=max_range,
                  line=dict(color="black", width=2))

    return fig

def plot2(userdata):
    fig = px.scatter(userdata,
                     y="B11 Radiance (W/m2/sr/um)",
                     x="B11 Model Radiance (W/m2/sr/um)",
                     hover_data=["Buoy ID", "Product ID", "Date"])

    fig.update_traces(marker=dict(size=5, color='red'), textposition='top center')

    hover_template = '<br>'.join([
        'B11 Radiance (W/m2/sr/um) = %{y}',
        'B11 Model Radiance (W/m2/sr/um) = %{x}',
        'Buoy ID = %{customdata[0]}',
        'Product ID = %{customdata[1]}',
        'Date = %{customdata[2]}'
    ])
    fig.update_traces(hovertemplate=hover_template)


    fig.update_layout(title='Band 11: Landsat Image Radiance vs. Buoy-Derived Modeled Radiance',
                      yaxis_title='B11 Landsat Image Radiance(W/m²/sr/μm)',
                      xaxis_title='B11 Buoy-Derived Model Radiance (W/m²/sr/μm)',
                      hoverlabel=dict(bgcolor="black", font_size=12, font_color="white"),
                      shapes=[
                          # Rectangle around the plot area
                          dict(type="rect",
                               xref="paper", yref="paper",
                               x0=0, y0=0, x1=1, y1=1,
                               line=dict(color="black", width=0.5)),
                      ],
                      plot_bgcolor='white',  # Background color inside the plot
                      paper_bgcolor='white',  # Background color outside the plot
                      font=dict(color='black'))

    # Set the same scale for both axes
    min_range, max_range = 5, 11

    fig.update_xaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=1)
    fig.update_yaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=1)

    # Add a diagonal line y=x
    fig.add_shape(type="line",
                  x0=min_range, y0=min_range, x1=max_range, y1=max_range,
                  line=dict(color="black", width=2))

    return fig


def plot3(userdata):
    fig = px.scatter(userdata,
                     y="SC Temp (K)",
                     x="Skin Temp (K)",
                     hover_data=["Buoy ID", "Product ID", "Date"])

    fig.update_traces(marker=dict(size=5, color='red'), textposition='top center')

    hover_template = '<br>'.join([
        'SC Temp (K) = %{y}',
        'Skin Temp (K) = %{x}',
        'Buoy ID = %{customdata[0]}',
        'Product ID = %{customdata[1]}',
        'Date = %{customdata[2]}'
    ])
    fig.update_traces(hovertemplate=hover_template)

    fig.update_layout(title='SC-Derived Surface Temperature (K) vs. Buoy Surface Temperature (K)',
                      yaxis_title='SC-Derived Surface Temperature (K)',
                      xaxis_title='Buoy Surface Temperature (K)',
                      hoverlabel=dict(bgcolor="black", font_size=12, font_color="white"),
                      shapes=[
                          # Rectangle around the plot area
                          dict(type="rect",
                               xref="paper", yref="paper",
                               x0=0, y0=0, x1=1, y1=1,
                               line=dict(color="black", width=0.5)),
                      ],
                      plot_bgcolor='white',  # Background color inside the plot
                      paper_bgcolor='white',  # Background color outside the plot
                      font=dict(color='black'))

    # Set the same scale for both axes
    min_range, max_range = 270, 310

    fig.update_xaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=5)
    fig.update_yaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=5)

    # Add a diagonal line y=x
    fig.add_shape(type="line",
                  x0=min_range, y0=min_range, x1=max_range, y1=max_range,
                  line=dict(color="black", width=2))

    return fig

def plot4(userdata):
    fig = px.scatter(userdata,
                     y="SW Temp (K)",
                     x="Skin Temp (K)",
                     hover_data=["Buoy ID", "Product ID", "Date"])

    fig.update_traces(marker=dict(size=6, color='red'), textposition='top center')

    hover_template = '<br>'.join([
        'SW Temp (K) = %{y}',
        'Skin Temp (K) = %{x}',
        'Buoy ID = %{customdata[0]}',
        'Product ID = %{customdata[1]}',
        'Date = %{customdata[2]}'
    ])
    fig.update_traces(hovertemplate=hover_template)

    fig.update_layout(title='SW-Derived Surface Temperature (K) vs. Buoy Surface Temperature (K)',
                      yaxis_title='SW-Derived Surface Temperature (K)',
                      xaxis_title='Buoy Surface Temperature (K)',
                      hoverlabel=dict(bgcolor="black", font_size=12, font_color="white"),
                      shapes=[
                          # Rectangle around the plot area
                          dict(type="rect",
                               xref="paper", yref="paper",
                               x0=0, y0=0, x1=1, y1=1,
                               line=dict(color="black", width=0.5)),
                      ],
                      plot_bgcolor='white',  # Background color inside the plot
                      paper_bgcolor='white',  # Background color outside the plot
                      font=dict(color='black'))

    # Set the same scale for both axes
    min_range, max_range = 270, 310

    fig.update_xaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=5)
    fig.update_yaxes(range=[min_range, max_range], color='black', showgrid=True, tickmode='linear', dtick=5)

    # Add a diagonal line y=x
    fig.add_shape(type="line",
                  x0=min_range, y0=min_range, x1=max_range, y1=max_range,
                  line=dict(color="black", width=2))

    return fig



with st.container(border=True):
    st.markdown(custom_css, unsafe_allow_html=True)
    st.title("Select Satellite")
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Landsat-8", key="landsat8"):
            st.session_state.data_folder = "buoy/Landsat8"
    with col2:
        if st.button("Landsat-9", key="landsat9"):
            st.session_state.data_folder = "buoy/Landsat9"
        
    data_folder = st.session_state.get('data_folder', None)
    if data_folder == "buoy/Landsat8":
        st.markdown("## Data Source: Landsat-8")
    elif data_folder == "buoy/Landsat9":
        st.markdown("## Data Source: Landsat-9")

# Function to create a toggle switch with an input box


# st.markdown("<br><br>", unsafe_allow_html=True)

years, months = generate_date_range(2014, datetime.now().year)

with st.container(border=True):
    st.header("Select Start Date")
    start_date_col1, start_date_col2, start_date_col3 = st.columns(3)
    with start_date_col1:
        start_year = int(st.selectbox("Year", years, key="start_year"))
    with start_date_col2:
        start_month = int(st.selectbox("Month", months, key="start_month"))
    with start_date_col3:
        start_days = days_in_month(start_year, start_month)
        start_day = int(st.selectbox("Day", start_days, key="start_day"))

    # st.markdown("<br><br>", unsafe_allow_html=True)

    st.header("Select End Date")
    end_date_col1, end_date_col2, end_date_col3 = st.columns(3)
    with end_date_col1:
        end_year = int(st.selectbox("Year", years, key="end_year"))
    with end_date_col2:
        end_month = int(st.selectbox("Month", months, key="end_month"))
    with end_date_col3:
        end_days = days_in_month(end_year, end_month)
        end_day = int(st.selectbox("Day", end_days, key="end_day"))

    start_date = datetime(start_year, start_month, start_day).date()
    end_date = datetime(end_year, end_month, end_day).date()

    # Ensure end date is not before start date
    if end_date < start_date:
        st.error("End date cannot be before start date. Please select a valid date range.")
    else:
        col1, col2 = st.columns([1, 1])
        with col1:
            st.write(f"Selected start date: {int(start_year)}-{int(start_month):02d}-{int(start_day):02d}")
        with col2:
            st.write(f"Selected end date: {int(end_year)}-{int(end_month):02d}-{int(end_day):02d}")

with st.container(border=True):
    st.subheader("Select the required variables and adjust their values below:")

    dp_value = toggle_with_input(
        label="Dewpoint depression (K) ",
        key_toggle="Key3",
        key_input="Input3"
    )

    distance_to_clouds_value = toggle_with_input(
        label="Distance to clouds (Km) ",
        key_toggle="Key2",
        key_input="Input2"
    )

    buoy_ids_list = toggle_with_input(
        label="Buoy ID",
        key_toggle="Key4",
        key_input="Input4"
    )

    cloud_cover_value = toggle_with_input(
        label="Cloud cover % ",
        key_toggle="Key1",
        key_input="Input1"
    )

# Apply some custom CSS to control margins and padding
st.markdown(
    """
    <style>
    .custom-toggle-container {
        display: flex;
        align-items: center;
        margin-bottom: 10px;
    }
    .custom-toggle-label {
        flex: 1;
        margin-right: 10px;
    }
    .custom-toggle-switch {
        flex: 1;
    }
    .custom-input-box {
        margin-top: 5px;
    }
    </style>
    """, unsafe_allow_html=True)



st.markdown(apply_filters_css, unsafe_allow_html=True)
col1, col2 = st.columns([1,1])
with col1:
    # Add a unique class to the "Apply Filters" button
    apply_filters = st.button("Apply Filters", key="apply_filters", help="Click to apply filters")

with st.container(border=True):  
    if apply_filters:
        st.session_state.userdata = None
        st.session_state.fig = None
        if 'data_folder' in st.session_state:
            data_folder = st.session_state.data_folder
            data = read_and_combine_csvs(data_folder, start_year, end_year)
            if data is None:
                st.markdown('<p style="background-color: yellow; color: black; padding: 10px;">No data found for the current settings</p>', unsafe_allow_html=True)
            if data is not None:
                st.session_state.userdata = filter_data(data, start_date, end_date, dp_value, distance_to_clouds_value, cloud_cover_value, buoy_ids_list)
        else:
            st.error("Please select a satellite data source.")

        st.header("Applied filters")

        def write_bullet_point(text):
            st.markdown(f"<ul style='margin: 0;'><li>{text}</li></ul>", unsafe_allow_html=True)

        if buoy_ids_list:
            buoy_ids_str = ', '.join(buoy_ids_list)
            write_bullet_point(f"Selected buoy IDs : {buoy_ids_str}")

        if cloud_cover_value:
            write_bullet_point(f"Cloud cover % : {cloud_cover_value}")

        if distance_to_clouds_value:
            write_bullet_point(f"Distance to clouds (Km) : {distance_to_clouds_value}")

        if dp_value:
            write_bullet_point(f"Dewpoint depression (K) : {dp_value}")

        write_bullet_point(f"Selected start date : {start_year}-{start_month}-{start_day}")
        write_bullet_point(f"Selected end date : {end_year}-{end_month}-{end_day}")
        st.write(" ")
        
# st.markdown("<br><br>", unsafe_allow_html=True)
    
if data is not None:
    st.session_state.userdata=filter_data(data, start_date, end_date, dp_value, distance_to_clouds_value, cloud_cover_value,  buoy_ids_list)
  
if st.session_state.userdata is not None:
    st.write("The filtered validation data is now ready for your review. You can download it by clicking on the 'Download' button below.")
    columns_to_drop = ["Buoy Data Comment", "GEOS Data Comment", "D2C Comment"]
    st.session_state.userdata = st.session_state.userdata.drop(columns=columns_to_drop, errors='ignore')
    st.write(st.session_state.userdata)

if 'selected_points' not in st.session_state:
    st.session_state.selected_points = None

if 'fig' not in st.session_state:
    st.session_state.fig = None

# Inject the custom CSS
st.markdown(custom_css, unsafe_allow_html=True)

# Create a row of 4 buttons with no space between them
col1, col2, col3, col4 = st.columns(4)

# Create placeholders for the plots
plot_placeholder = st.empty()
selected_points = None
matching_row = None

with st.container(border=True):
    with col1:
        if st.button("Band 10 Radiance"):
            if 'userdata' in st.session_state and st.session_state.userdata is not None:
                st.session_state.fig= plot1(st.session_state.userdata)
                st.session_state.button_clicked = 1
            else:
                st.write("No data to plot")


    with col2:
        if st.button("Band 11 Radiance "):      
            if 'userdata' in st.session_state and st.session_state.userdata is not None:
                st.session_state.fig= plot2(st.session_state.userdata)
                st.session_state.button_clicked = 2
            else:
                st.write("No data to plot")

    with col3:
        if st.button("Single channel ST"):
            if 'userdata' in st.session_state and st.session_state.userdata is not None:
                st.session_state.fig= plot3(st.session_state.userdata)
                st.session_state.button_clicked = 3
            else:
                st.write("No data to plot")

    with col4:
        if st.button("Split window ST"):
            if 'userdata' in st.session_state and st.session_state.userdata is not None:
                st.session_state.fig= plot4(st.session_state.userdata)
                st.session_state.button_clicked = 4
            else:
                st.write("No data to plot")

    if st.session_state.fig:
        st.markdown(
            """
            <h5 style='text-align: center;'>
                Click on a data point for more information
            </h5>
            """,
            unsafe_allow_html=True
        )    
        st.container()
        data = st.session_state.userdata
        selected_points = plotly_events(st.session_state.fig, click_event=True, hover_event=False)
        if selected_points:
            clicked_point = selected_points[0]

            clicked_x = clicked_point['x']
            clicked_y = clicked_point['y']

            if st.session_state.button_clicked == 1:
                matching_row = data[(data['B10 Radiance (W/m2/sr/um)'] == clicked_y) & (data['B10 Model Radiance (W/m2/sr/um)'] == clicked_x)]
            elif st.session_state.button_clicked == 2:
                matching_row = data[(data['B11 Radiance (W/m2/sr/um)'] == clicked_y) & (data['B11 Model Radiance (W/m2/sr/um)'] == clicked_x)]
            elif st.session_state.button_clicked == 3:
                matching_row = data[(data['SC Temp (K)'] == clicked_y) & (data['Skin Temp (K)'] == clicked_x)]
            elif st.session_state.button_clicked == 4:
                matching_row = data[(data['SW Temp (K)'] == clicked_y) & (data['Skin Temp (K)'] == clicked_x)]

            columns_to_drop = ["Buoy Data Comment", "GEOS Data Comment", "D2C Comment"]

            matching_row = matching_row.drop(columns=columns_to_drop, errors='ignore')
            
            st.session_state.matching_row = matching_row
        
            if not matching_row.empty:
                buoy_id = matching_row['Buoy ID'].values[0]
                product_id = matching_row['Product ID'].values[0]
                st.markdown(f"""
                    <div style="text-align: center;">
                        <h5>Buoy ID: {buoy_id}, Product ID: {product_id} </h5>
                    </div>
                    """, unsafe_allow_html=True)
                # st.write("")
                folder_name = f"{buoy_id}_{product_id}"
                st.markdown("### Selected Data Information")            
                st.write(matching_row)
                st.write("")
                base_path = os.path.join('buoy/figures', folder_name)
                geos_fig_filename = f"{buoy_id}_{product_id}_geos.png"
                gee_fig_filename = f"{buoy_id}_{product_id}_gee.png"
                geos_fig_path = os.path.join(base_path, 'geos_fig', geos_fig_filename)
                gee_fig_path = os.path.join(base_path, 'gee_fig', gee_fig_filename)


                # Check if the files exist and display images
                if os.path.exists(geos_fig_path) and os.path.exists(gee_fig_path):

                    st.image(gee_fig_path,  use_column_width=True) # landsat image 

                    st.markdown(f"""
                    <div style="text-align: center;">
                        <h5>Landsat Image</h5>
                    </div>
                    """, unsafe_allow_html=True)

                    st.image(geos_fig_path,  use_column_width=True) #geos5 atmospheric  profile
                    st.markdown(f"""
                    <div style="text-align: center;">
                        <h5>GEOS-5 Atmospheric Profile</h5>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.write("Images not found in the specified folders.")
            else:
                st.write("No matching data found in the original DataFrame.")
    else:
        st.write("Select data source to plot")

st.markdown("<br><br>", unsafe_allow_html=True)

