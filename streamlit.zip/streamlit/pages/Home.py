import streamlit as st
from PIL import Image
from datetime import datetime


st.set_page_config(layout="wide")
st.sidebar.image("pictures/RIT_hor_w.png", use_column_width=True)

# Load the image using PIL
image = Image.open("pictures/combined_image.png")

# Display the image using Streamlit's built-in method
st.image(image, use_column_width=True)

# Inject CSS to disable pointer events
st.markdown(
    """
    <style>
    img {
        pointer-events: none;
    }
    </style>
    """,
    unsafe_allow_html=True)

st.title("Landsat Thermal Validation")

st.write( """
         Welcome to the Landsat Thermal Validation website, developed by the Rochester Institute of Technology (RIT). 
         This platform provides near real-time validation of the Thermal Infrared Sensors (TIRS) onboard Landsat-8 and Landsat-9.
         The primary goal is to include a comprehensive validation for the suite of Landsat thermal sensor and facilitate open access to the data for end users.
         """)

st.markdown("### What we do")

markdown_text = """
- **NOAA Buoy Network:** The reference data is sourced from the National Oceanic and Atmospheric Administration (NOAA) buoy network, which operates across several near-shore and inland water sites in CONUS (Continental United States). Water remains an ideal target for monitoring the long-term performance of TIRS due to its spectrally stable and well-defined emissivity. These instrumented buoys provide water bulk temperature measurements and wind speed, which enables an adjustment to water surface temperature, or “skin temperature” based on the methodology developed by [Padula (2008) ](https://www.proquest.com/docview/304386040?pq-origsite=gscholar&fromopenview=true&sourcetype=Dissertations%20&%20Theses) .
- **Forward Modeling:** The validation methodology employs a traditional forward-modeling workflow developed by the Landsat Calibration & Validation Team at RIT. This workflow models at-sensor spectral radiance for each TIRS band from the reference water surface measurements. The atmosphere is modeled using the MODTRAN radiative transfer model, which incorporates atmospheric profiles from GEOS-5 reanalysis product produced by the NASA Global Modeling and Assimilation Office (GMAO).
- **Surface Temperature Validation:** The website also compares the derived Level 2 surface temperature product, calculated using both the [split window](https://www.mdpi.com/2072-4292/12/2/224) and single channel algorithms, against reference water surface measurements.
"""

# Render the bullet points in Streamlit
st.markdown(markdown_text)

st.header("Helpful Resources")

additional_links = """
- [More information on Landsat](https://www.usgs.gov/landsat-missions)
- [The National Data Buoy Center](https://www.ndbc.noaa.gov)
- [The NASA Global Modeling and Assimilation Office](https://gmao.gsfc.nasa.gov)

"""

st.markdown(additional_links)

st.markdown("<div class='contact-info'><h2 style='color: white;'>Contact Information</h2>"
            "<a href='mailto:adgpci@cis.rit.edu' style='color: #ADD8E6;'>Aaron Gerace</a>"+ " and " +  "<a href='mailto:eoncis@rit.edu' style='color: #ADD8E6;'>Rehman Eon</a></p></div>", unsafe_allow_html=True)

st.markdown("<br><br>", unsafe_allow_html=True)
st.markdown("<br><br>", unsafe_allow_html=True)

